﻿# Changes

- `app/dashboard/page.tsx` — Changed the dashboard banner image to a savings photo showing coins and a growing plant.
- `docs/image-credits.md` — Added the photo source, creator, and license.
- `CHANGES.md` — Added this batch summary.
